import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

// Screens
import SoulIntro from "./SoulIntro";
import SoulLogin from "./SoulLogin";

// Forms
import AICompatibility from "../Forms/ai-compatibility/AICompatibility";
import BasicInfo from "../forms/basic-info/BasicInfo";
import Education from "../Forms/education/Education";
import Family from "../Forms/marriage/Marriage";
import Lifestyle from "../Forms/lifestyle/Lifestyle";
import Personality from "../Forms/personality/Personality";
import Beliefs from "../Forms/beliefs/Beliefs";
import Communication from "../Forms/communication/Communication";
import Marriage from "../Forms/marriage/Marriage";
import Future from "../Forms/future/Future";
import Verification from "../Forms/verification/Verification";

// Assets
import MainBanner from "../../../assets/main-hero/main.jpg";
import Logo from "../../../assets/logo/logo.png";

/* ---------------------------------------
   STORAGE KEYS
--------------------------------------- */
const STORAGE_KEYS = {
  SCREEN: "soul_screen",
  STEP: "soul_step",
  LOGGED_IN: "soul_logged_in",
};

const Home = () => {
  /* ---------------------------------------
     STATE (RESTORED)
  --------------------------------------- */
  const [screen, setScreen] = useState(
    () => localStorage.getItem(STORAGE_KEYS.SCREEN) || "intro"
  );

  const [step, setStep] = useState(
    () => Number(localStorage.getItem(STORAGE_KEYS.STEP)) || 1
  );

  const [isChanging, setIsChanging] = useState(false);
  const [name, setName] = useState("");
  const [basicInfo, setBasicInfo] = useState({});

  /* ---------------------------------------
     SAVE STATE
  --------------------------------------- */
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SCREEN, screen);
  }, [screen]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STEP, step);
  }, [step]);

  /* ---------------------------------------
     LOGIN PROTECTION
  --------------------------------------- */
  useEffect(() => {
    const loggedIn = localStorage.getItem(STORAGE_KEYS.LOGGED_IN);
    if (!loggedIn && screen === "flow") {
      setScreen("login");
    }
  }, [screen]);

  /* ---------------------------------------
     STEP HANDLERS
  --------------------------------------- */
  const nextStep = () => {
    setIsChanging(true);
    setTimeout(() => {
      setStep((s) => s + 1);
      setIsChanging(false);
    }, 400);
  };

  const handleBack = () => {
    if (screen === "login") {
      setScreen("intro");
      return;
    }

    if (screen === "flow") {
      if (step > 1) {
        setStep((s) => s - 1);
      } else {
        setScreen("login");
      }
    }
  };

  /* ---------------------------------------
     FORMS
  --------------------------------------- */
  const FORM_MAP = {
    1: (
      <BasicInfo
        onNext={nextStep}
        setName={setName}
        setBasicInfo={setBasicInfo}
      />
    ),
    2: <Education onNext={nextStep} />,
    3: <Family onNext={nextStep} />,
    4: <Lifestyle onNext={nextStep} />,
    5: <Personality onNext={nextStep} />,
    6: <Beliefs onNext={nextStep} />,
    7: <Communication onNext={nextStep} />,
    8: <Marriage onNext={nextStep} />,
    9: <Future onNext={nextStep} />,
    10: <AICompatibility onNext={nextStep} />,
    11: <Verification />,
  };

  /* ---------------------------------------
     UI
  --------------------------------------- */
  return (
    <div
      className="min-h-screen w-full relative flex flex-col items-center overflow-x-hidden bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `linear-gradient(
          rgba(225,225,225,0.0),
          rgba(225,218,34,0.22)
        ), url('${MainBanner}')`,
      }}
    >
      {/* HEADER */}
      <header className="w-full container mx-auto px-8 py-8 lg:pt-20 pt-10 pb-0 flex justify-between items-center z-20">
        {/* Back Button */}
        {screen !== "intro" && (
          <button
            onClick={handleBack}
            className="px-5 py-2 rounded-full bg-black backdrop-blur text-white
                       text-sm font-semibold shadow-md hover:scale-105 transition"
          >
            ← Back
          </button>
        )}

        {/* Logo */}
        <div className="p-0.5 rounded-2xl shadow-[0_0_25px_rgba(0,0,0,0.35)] mx-auto">
          <img
            src={Logo}
            alt="Logo"
            className="w-32 md:w-50 bg-white rounded-2xl object-contain"
          />
        </div>

        {/* Spacer */}
        <div className="w-20" />
      </header>

      {/* MAIN */}
      <main className="flex-1 w-full max-w-7xl px-6 flex items-center justify-center z-10 pb-20">
        <AnimatePresence mode="wait">
          {screen === "intro" && (
            <SoulIntro key="intro" onStart={() => setScreen("login")} />
          )}

          {screen === "login" && (
            <SoulLogin
              key="login"
              onSuccess={() => {
                localStorage.setItem(STORAGE_KEYS.LOGGED_IN, "true");
                setScreen("flow");
              }}
            />
          )}

          {screen === "flow" && (
            <motion.div
              key="flow"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="relative w-full"
            >
              <div className="w-full rounded-[3rem] p-10 pt-20">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={step}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.4 }}
                  >
                    {FORM_MAP[step]}
                  </motion.div>
                </AnimatePresence>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};

export default Home;
