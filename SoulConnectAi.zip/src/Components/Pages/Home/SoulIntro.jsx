import React from "react";
import { motion, AnimatePresence } from "framer-motion";

const SoulIntro = ({ onStart }) => {
  // Variants for staggered text animation
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.3, delayChildren: 0.2 },
    },
    exit: { opacity: 0, scale: 0.95, transition: { duration: 0.4 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" },
    },
  };

  return (
    <div className="relative min-h-[60vh] flex items-center justify-center overflow-hidden px-6">
      {/* Soft Background Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-125 h-125 bg-yellow-100/30 rounded-full blur-[120px] -z-10" />

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        exit="exit"
        className="text-center container mx-auto"
      >
        <motion.h1
          variants={itemVariants}
          className="text-5xl md:text-8xl font-bold tracking-tight text-slate-900 mb-8 leading-[1.1]"
        >
          Let’s discover your perfect <br />
          <span className="block italic text-white relative max-w-xl mx-auto">
            <svg
              className="absolute -bottom-6 left-0 w-full"
              viewBox="0 0 300 20"
              fill="none"
            >
              <path
                d="M5 15C50 5 150 5 295 15"
                stroke="white"
                strokeWidth="4"
                strokeLinecap="round"
              />
            </svg>
            connection
          </span>
        </motion.h1>

        <motion.p
          variants={itemVariants}
          className="text-slate-600 text-lg md:text-xl max-w-xl mx-auto mb-12 leading-relaxed"
        >
          A space where intuition meets intention. Answer a few thoughtful
          questions to reveal a match that truly resonates.
        </motion.p>

        <motion.div variants={itemVariants}>
          <button
            onClick={onStart}
            className="group relative px-12 py-5 bg-black text-white rounded-full font-bold text-lg overflow-hidden transition-all hover:shadow-[0_0_30px_rgba(212,175,55,0.4)]"
          >
            <span className="relative z-10">Start Your Journey</span>
            {/* Hover Slide Effect */}
            <div className="absolute inset-0 bg-[#d4af37] translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-in-out" />
          </button>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default SoulIntro;
