import React from 'react';

const ProgressIndicator = ({ currentStep, totalSteps }) => {
  return (
    <div className="flex items-center gap-2">
      {Array.from({ length: totalSteps }, (_, i) => i + 1).map((step) => (
        <div
          key={step}
          className={`h-1.5 rounded-full transition-all duration-500 ease-out ${
            step === currentStep
              ? 'w-10 gradient-primary'
              : step < currentStep
              ? 'w-3 bg-primary/40'
              : 'w-3 bg-border'
          }`}
        />
      ))}
    </div>
  );
};

export default ProgressIndicator;
