import React, { useState } from 'react';

const locations = [
  { name: 'United States', emoji: '🇺🇸', gradient: 'from-blue-500/20 to-red-500/20' },
  { name: 'India', emoji: '🇮🇳', gradient: 'from-orange-500/20 to-green-500/20' },
  { name: 'United Kingdom', emoji: '🇬🇧', gradient: 'from-blue-600/20 to-red-600/20' },
  { name: 'Canada', emoji: '🇨🇦', gradient: 'from-red-500/20 to-white/20' },
  { name: 'Australia', emoji: '🇦🇺', gradient: 'from-blue-500/20 to-yellow-500/20' },
  { name: 'Germany', emoji: '🇩🇪', gradient: 'from-yellow-500/20 to-red-500/20' },
];

const StepLocation = ({ onNext }) => {
  const [hoveredIndex, setHoveredIndex] = useState(null);

  return (
    <div className="space-y-8 animate-fade-up">
      <h1 className="text-5xl md:text-6xl font-display font-bold tracking-tight text-foreground">
        Where are you?
      </h1>
      
      <div className="grid grid-cols-2 gap-3 md:gap-4">
        {locations.map((location, index) => (
          <button
            key={location.name}
            onClick={onNext}
            onMouseEnter={() => setHoveredIndex(index)}
            onMouseLeave={() => setHoveredIndex(null)}
            className="group relative h-28 md:h-36 rounded-2xl md:rounded-3xl overflow-hidden transition-all duration-300 hover:-translate-y-1 animate-scale-in"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            {/* Background layers */}
            <div className="absolute inset-0 bg-card/80 backdrop-blur-xl border-2 border-border group-hover:border-primary/50 transition-colors" />
            <div className={`absolute inset-0 bg-gradient-to-br ${location.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
            
            {/* Content */}
            <div className="relative h-full flex flex-col items-center justify-center gap-2 md:gap-3">
              <span className="text-3xl md:text-4xl group-hover:scale-125 transition-transform duration-300">
                {location.emoji}
              </span>
              <span className="font-semibold text-sm md:text-base text-muted-foreground group-hover:text-foreground transition-colors">
                {location.name}
              </span>
            </div>
            
            {/* Hover glow */}
            {hoveredIndex === index && (
              <div className="absolute -inset-px rounded-2xl md:rounded-3xl border-2 border-primary/50 animate-pulse" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default StepLocation;
