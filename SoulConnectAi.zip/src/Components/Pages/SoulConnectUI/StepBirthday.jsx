import React, { useState } from 'react';

const StepBirthday = ({ name, onNext }) => {
  const [date, setDate] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  return (
    <div className="space-y-10 animate-fade-up">
      <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tight text-foreground">
        Born on...
      </h1>
      
      {/* Enhanced Date Input */}
      <div className="relative">
        <div className={`absolute -inset-1 rounded-3xl bg-gradient-to-r from-primary/50 via-accent/30 to-highlight/50 blur-lg transition-opacity duration-300 ${isFocused ? 'opacity-100' : 'opacity-0'}`} />
        <div className={`relative bg-card/80 backdrop-blur-xl rounded-3xl border-2 transition-all duration-300 overflow-hidden ${isFocused ? 'border-primary shadow-glow' : 'border-border'}`}>
          <div className="flex items-center gap-4 px-6 py-2">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <svg className="w-6 h-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              className="flex-1 bg-transparent py-4 text-xl md:text-2xl font-body font-medium focus:outline-none cursor-pointer"
            />
          </div>
        </div>
      </div>
      
      {/* Enhanced Button */}
      <button
        onClick={onNext}
        className="group relative px-10 py-5 rounded-2xl font-bold text-lg overflow-hidden transition-all duration-300 hover:-translate-y-1"
      >
        {/* Button background */}
        <div className="absolute inset-0 gradient-primary" />
        <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
        
        {/* Button content */}
        <span className="relative flex items-center gap-3 text-primary-foreground">
          Confirm Identity
          <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
          </svg>
        </span>
        
        {/* Glow effect */}
        <div className="absolute -inset-1 gradient-primary rounded-2xl blur-xl opacity-0 group-hover:opacity-50 transition-opacity -z-10" />
      </button>
    </div>
  );
};

export default StepBirthday;
