import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ProgressIndicator from './ProgressIndicator';
import AIMessageCard from './AIMessageCard';
import StepName from './StepName';
import StepBirthday from './StepBirthday';
import StepLocation from './StepLocation';
import StepIntention from './StepIntention';
import CompletionScreen from './CompletionScreen';

const AI_MESSAGES = [
  "Every great love story starts with a name. What's yours?",
  "Beautiful. Now tell me, when did your journey in this world begin?",
  "The world is vast and full of wonder. Where are you blooming?",
  "What does your heart truly seek in this connection?",
];

const SoulConnectUI = () => {
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [isAnimating, setIsAnimating] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  const handleNext = () => {
    setIsAnimating(true);
    setTimeout(() => {
      setStep((s) => s + 1);
      setIsAnimating(false);
    }, 600);
  };

  if (isComplete) return <CompletionScreen name={name} />;

  return (
    <div className="relative min-h-screen bg-[#FDFCFB] text-[#4A4238] font-body overflow-hidden selection:bg-gold-200">
      
      {/* --- PHASE 1: LUXURY BACKGROUND --- */}
      <div className="fixed inset-0 z-0">
        {/* Soft Golden Orbs */}
        <div className="absolute top-[-10%] right-[-5%] w-[60vw] h-[60vw] rounded-full bg-gradient-to-br from-[#F3E7E9] to-[#E3EEFF] opacity-50 blur-[100px]" />
        <div className="absolute bottom-[-10%] left-[-5%] w-[50vw] h-[50vw] rounded-full bg-[#FEF9E7] opacity-60 blur-[120px]" />
        
        {/* Subtle Silk Texture */}
        <div className="absolute inset-0 opacity-[0.02] pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/natural-paper.png')]" />
      </div>

      {/* --- PHASE 2: MINIMALIST NAV --- */}
      <nav className="relative z-30 flex justify-between items-center px-8 md:px-20 py-10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-gradient-to-tr from-[#D4AF37] to-[#F9F295] rounded-full shadow-[0_4px_15px_rgba(212,175,55,0.3)] flex items-center justify-center">
            <span className="text-white text-lg">✨</span>
          </div>
          <span className="font-display font-bold text-xl tracking-widest uppercase text-[#8C7851]">
            Soul<span className="text-[#C5A059]">Connect</span>
          </span>
        </div>
        
        {/* Refined Progress Bar */}
        <div className="bg-white/40 backdrop-blur-md border border-[#D4AF37]/20 px-5 py-2 rounded-full shadow-sm">
          <ProgressIndicator currentStep={step} totalSteps={4} />
        </div>
      </nav>

      {/* --- PHASE 3: GRID LAYOUT --- */}
      <main className="relative z-20 max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-16 min-h-[calc(100vh-200px)] items-center">
        
        {/* LEFT: Interaction Zone */}
        <div className="lg:col-span-7">
          <div className={`transition-all duration-1000 ease-in-out ${
              isAnimating ? 'opacity-0 translate-y-4 scale-[0.98]' : 'opacity-100 translate-y-0 scale-100'
            }`}>
            
            {/* Status Pill */}
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#C5A059]/10 rounded-full mb-8">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059] animate-pulse" />
              <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#8C7851]">Guided Experience</span>
            </div>

            {/* Input Card: The "Jewelry Box" effect */}
            <div className="relative bg-white/60 border border-white p-10 md:p-14 rounded-[3rem] backdrop-blur-2xl shadow-[20px_20px_60px_#d9d9d9,-20px_-20px_60px_#ffffff]">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-1 bg-gradient-to-r from-transparent via-[#D4AF37]/40 to-transparent" />
              
              {step === 1 && <StepName onNext={(val) => { setName(val); handleNext(); }} />}
              {step === 2 && <StepBirthday name={name} onNext={handleNext} />}
              {step === 3 && <StepLocation onNext={handleNext} />}
              {step === 4 && <StepIntention onComplete={() => setIsComplete(true)} />}
            </div>
          </div>
        </div>

        {/* RIGHT: AI Guide Card */}
        <div className="lg:col-span-5 flex justify-center lg:justify-end">
          <div className="relative group">
            {/* Soft Glow Behind AI */}
            <div className="absolute -inset-10 bg-[#D4AF37]/5 rounded-full blur-[80px]" />
            
            <AIMessageCard
              message={step === 2 && name ? AI_MESSAGES[1].replace('Beautiful', `Beautiful, ${name}`) : AI_MESSAGES[step - 1]}
              isAnimating={isAnimating}
              theme="light" // Pass a theme prop to your message card
            />
          </div>
        </div>
      </main>

      {/* Subtle Bottom Accent */}
      <div className="fixed bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#D4AF37]/20 to-transparent" />
    </div>
  );
};

export default SoulConnectUI;