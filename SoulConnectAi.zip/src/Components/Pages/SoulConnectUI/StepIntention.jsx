import React, { useState } from 'react';

const intentions = [
  { 
    title: 'Find Love', 
    description: 'A deep, meaningful connection', 
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
      </svg>
    ),
    gradient: 'from-primary to-primary-glow' 
  },
  { 
    title: 'Make Friends', 
    description: 'Genuine friendships that last', 
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
      </svg>
    ),
    gradient: 'from-accent to-accent-glow' 
  },
  { 
    title: 'Network', 
    description: 'Professional connections', 
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    ),
    gradient: 'from-deep to-accent' 
  },
  { 
    title: 'Explore', 
    description: 'Open to all possibilities', 
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
    gradient: 'from-highlight to-primary' 
  },
];

const StepIntention = ({ onComplete }) => {
  const [selectedIndex, setSelectedIndex] = useState(null);

  const handleSelect = (index) => {
    setSelectedIndex(index);
    setTimeout(() => onComplete(), 400);
  };

  return (
    <div className="space-y-8 animate-fade-up">
      <h1 className="text-5xl md:text-6xl font-display font-bold tracking-tight text-foreground">
        Your intention?
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
        {intentions.map((intention, index) => (
          <button
            key={intention.title}
            onClick={() => handleSelect(index)}
            className={`relative overflow-hidden p-5 md:p-6 rounded-2xl md:rounded-3xl text-left transition-all duration-300 group hover:-translate-y-1 animate-scale-in ${
              selectedIndex === index ? 'scale-95' : ''
            }`}
            style={{ animationDelay: `${index * 75}ms` }}
          >
            {/* Background gradient on hover */}
            <div className={`absolute inset-0 bg-gradient-to-br ${intention.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
            
            {/* Default background */}
            <div className="absolute inset-0 bg-card/80 backdrop-blur-xl border-2 border-border group-hover:border-transparent group-hover:opacity-0 transition-all duration-300" />
            
            <div className="relative z-10 flex items-start gap-4">
              {/* Icon */}
              <div className="w-14 h-14 rounded-2xl bg-primary/10 group-hover:bg-white/20 flex items-center justify-center flex-shrink-0 transition-colors text-primary group-hover:text-primary-foreground">
                {intention.icon}
              </div>
              
              <div>
                <h3 className="text-lg md:text-xl font-display font-bold text-foreground group-hover:text-primary-foreground transition-colors">
                  {intention.title}
                </h3>
                <p className="text-sm text-muted-foreground group-hover:text-primary-foreground/80 transition-colors mt-0.5">
                  {intention.description}
                </p>
              </div>
            </div>
            
            {/* Selection indicator */}
            {selectedIndex === index && (
              <div className="absolute inset-0 bg-primary/90 flex items-center justify-center animate-scale-in">
                <svg className="w-12 h-12 text-primary-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default StepIntention;
