import React from 'react';

const CompletionScreen = ({ name }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center animate-fade-up">
      {/* Success Animation */}
      <div className="relative mb-8">
        <div className="w-32 h-32 gradient-primary rounded-full flex items-center justify-center shadow-glow animate-glow-pulse">
          <span className="text-6xl">💫</span>
        </div>
        <div className="absolute -inset-4 border-2 border-primary/20 rounded-full animate-ping" />
      </div>
      
      <h1 className="text-4xl md:text-6xl font-display font-bold text-foreground mb-4">
        Welcome, <span className="text-gradient">{name}</span>
      </h1>
      
      <p className="text-xl text-muted-foreground max-w-md mb-10">
        Your soul profile has been created. The universe is now aligning your perfect connections.
      </p>
      
      <button className="px-12 py-5 gradient-primary rounded-2xl font-bold text-primary-foreground shadow-glow hover:shadow-[0_20px_60px_hsl(355_78%_60%/0.35)] hover:-translate-y-1 transition-all duration-300 text-lg">
        Begin Your Journey
      </button>
      
      {/* Decorative elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-primary rounded-full animate-ping" />
        <div className="absolute top-1/3 right-1/4 w-3 h-3 bg-accent rounded-full animate-pulse" />
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-highlight rounded-full animate-ping animation-delay-200" />
        <div className="absolute bottom-1/4 right-1/3 w-3 h-3 bg-primary rounded-full animate-pulse animation-delay-100" />
      </div>
    </div>
  );
};

export default CompletionScreen;
