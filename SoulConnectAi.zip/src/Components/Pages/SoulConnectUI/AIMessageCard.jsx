import React, { useEffect, useState } from "react";
import aiAvatar from "../../../assets/download.png";

const AIMessageCard = ({ message, name, isAnimating }) => {
  const [displayedMessage, setDisplayedMessage] = useState("");

  const formatMessage = (msg) => {
    if (!name) return msg;
    return `${name}. ${msg}`;
  };

  useEffect(() => {
    if (!message) return;

    const finalMessage = formatMessage(message);
    let index = 0;

    setDisplayedMessage("");

    const interval = setInterval(() => {
      setDisplayedMessage(finalMessage.slice(0, index + 1));
      index++;

      if (index >= finalMessage.length) clearInterval(interval);
    }, 25);

    return () => clearInterval(interval);
  }, [message, name]);

  return (
    <div className="relative w-full max-w-md group">
      {/* Glass Card – UI UNCHANGED */}
      <div
        className={`relative z-10 p-8 md:p-10 glass-card rounded-[2.5rem] rounded-tr-lg transition-all duration-500 ${
          isAnimating
            ? "scale-95 opacity-0 blur-sm"
            : "scale-100 opacity-100 blur-0"
        }`}
      >
        <p className="text-xl md:text-2xl font-medium leading-relaxed">
          {displayedMessage}
          <span className="inline-block w-1 h-6 ml-1 bg-rose-400 animate-pulse rounded-full" />
        </p>
      </div>

      {/* Avatar – UNCHANGED */}
      <div className="absolute -bottom-24 -left-30">
        <img
          src={aiAvatar}
          alt="AI"
          className="w-24 h-24 rounded-full object-cover"
        />
      </div>
    </div>
  );
};

export default AIMessageCard;
