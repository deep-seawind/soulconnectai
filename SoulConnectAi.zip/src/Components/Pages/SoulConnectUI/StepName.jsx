import React, { useState } from 'react';

const StepName = ({ onNext }) => {
  const [name, setName] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  const handleSubmit = () => {
    if (name.trim()) {
      onNext(name);
    }
  };

  return (
    <div className="space-y-10 animate-fade-up">
      <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tight text-foreground">
        I am...
      </h1>
      
      {/* Enhanced Input Field */}
      <div className="relative">
        <div className={`absolute -inset-1 rounded-2xl bg-gradient-to-r from-primary/50 via-accent/30 to-highlight/50 blur-lg transition-opacity duration-300 ${isFocused ? 'opacity-100' : 'opacity-0'}`} />
        <div className={`relative bg-card/80 backdrop-blur-xl rounded-2xl border-2 transition-all duration-300 ${isFocused ? 'border-primary shadow-glow' : 'border-border'}`}>
          <input
            autoFocus
            type="text"
            value={name}
            placeholder="Your beautiful name"
            className="w-full bg-transparent px-6 py-5 text-2xl md:text-3xl font-body font-medium focus:outline-none placeholder:text-muted-foreground/40"
            onChange={(e) => setName(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
          />
          {/* Input decoration */}
          <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
            {name && (
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center animate-scale-in">
                <svg className="w-4 h-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Enhanced Button */}
      <button
        onClick={handleSubmit}
        disabled={!name.trim()}
        className="group flex items-center gap-4 text-lg font-semibold text-foreground hover:text-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <span className="relative">
          Next Chapter
          <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300" />
        </span>
        <span className="w-14 h-14 rounded-2xl bg-foreground flex items-center justify-center group-hover:bg-primary group-hover:shadow-glow group-hover:rounded-xl transition-all duration-300 group-disabled:bg-muted">
          <svg className="w-5 h-5 text-background group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
          </svg>
        </span>
      </button>
    </div>
  );
};

export default StepName;
