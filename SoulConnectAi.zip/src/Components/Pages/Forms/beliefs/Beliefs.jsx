import { useFormStore } from "../../../../store/formStore";

const Beliefs = ({ onNext }) => {
  const setAnswer = useFormStore(s => s.setAnswer);

  return (
    <div>
      <select onChange={e =>
        setAnswer("beliefs", { belief: e.target.value })
      }>
        <option>Spiritual</option>
        <option>Modern</option>
        <option>Traditional</option>
      </select>
      <button onClick={onNext}>Next</button>
    </div>
  );
};

export default Beliefs;
