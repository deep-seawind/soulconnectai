import { useFormStore } from "../../../../store/formStore";

const Family = ({ onNext }) => {
  const setAnswer = useFormStore(s => s.setAnswer);

  return (
    <div className="space-y-6">
      <select onChange={e =>
        setAnswer("family", { familyType: e.target.value })
      }>
        <option value="">Family Type</option>
        <option>Nuclear</option>
        <option>Joint</option>
      </select>

      <button onClick={onNext}>Next</button>
    </div>
  );
};

export default Family;
