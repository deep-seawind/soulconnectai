const Verification = () => {
  return (
    <div>
      <p>Upload ID / Verify Phone</p>
      <button>Finish</button>
    </div>
  );
};

export default Verification;
