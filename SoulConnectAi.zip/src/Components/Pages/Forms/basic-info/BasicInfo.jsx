import React, { useState } from "react";
import AIMessage from "../../Home/AIMessage";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

const BasicInfo = ({ onNext }) => {
  const fields = [
    {
      key: "fullName",
      label: "Full Name",
      type: "text",
      placeholder: "Your full name",
      message:
        "Every great story starts with a name. How should I address you?",
    },
    {
      key: "gender",
      label: "Gender",
      type: "select",
      options: ["Male", "Female", "Other"],
      message: "Identity matters. How do you identify yourself?",
    },
    {
      key: "dob",
      label: "Date of Birth",
      type: "date",
      message: "Time shapes us. When were you born?",
    },
    {
      key: "height",
      label: "Height (cm)",
      type: "number",
      message:
        "Physical details help create a complete picture. What is your height?",
    },
    {
      key: "weight",
      label: "Weight (kg)",
      type: "number",
      message: "And your weight?",
    },
    {
      key: "maritalStatus",
      label: "Marital Status",
      type: "select",
      options: ["Never Married", "Divorced", "Widowed"],
      message: "Your journey so far matters. What is your marital status?",
    },
    {
      key: "religion",
      label: "Religion / Community / Caste",
      type: "text",
      message: "Beliefs and roots shape values. Tell me about yours.",
    },
    {
      key: "country",
      label: "Country",
      type: "text",
      message: "Where in the world do you call home?",
    },
    {
      key: "state",
      label: "State",
      type: "text",
      message: "Which state do you live in?",
    },
    {
      key: "city",
      label: "City",
      type: "text",
      message: "Which city are you currently in?",
    },
    {
      key: "nationality",
      label: "Nationality",
      type: "text",
      message: "What is your nationality?",
    },
    {
      key: "citizenship",
      label: "Citizenship",
      type: "text",
      message: "Your legal identity matters too. What is your citizenship?",
    },
    {
      key: "languages",
      label: "Languages You Speak",
      type: "text",
      message: "Communication builds connection. Which languages do you speak?",
    },
    {
      key: "openToInterCommunity",
      label: "Open to marriage outside community/religion?",
      type: "select",
      options: ["Yes", "No", "Maybe"],
      message: "Are you open to connections beyond your community?",
    },
  ];

  const [fieldStep, setFieldStep] = useState(0);
  const [formData, setFormData] = useState({});
  const [displayName, setDisplayName] = useState("");
  const [submittedSteps, setSubmittedSteps] = useState({});
  const [basicInfo, setBasicInfo] = useState({});
  const [name, setName] = useState({});
  const navigate = useNavigate();

  const currentField = fields[fieldStep];
  const isNameField = currentField.key === "fullName";

  const handleChange = (e) => {
    const value = e.target.value;
    setFormData((prev) => ({
      ...prev,
      [currentField.key]: value,
    }));
  };

  const isNameFilled =
    formData.fullName && formData.fullName.toString().trim() !== "";

  const goToLastField = () => {
    if (!isNameFilled) return;
    setFieldStep(fields.length - 1);
  };

  const handleNext = () => {
    const value = formData[currentField.key];

    if (!value || value.toString().trim() === "") {
      return;
    }

    const trimmedValue = value.toString().trim();

    setFormData((prev) => ({
      ...prev,
      [currentField.key]: trimmedValue,
    }));

    setSubmittedSteps((prev) => ({
      ...prev,
      [currentField.key]: true,
    }));

    if (isNameField) {
      setName(trimmedValue);
      setDisplayName(trimmedValue);
    }

    if (fieldStep === fields.length - 1) {
      setBasicInfo(formData);
      onNext(); 
    } else {
      setFieldStep((prev) => prev + 1);
    }
    
  };

  const handlePrevious = () => {
    if (fieldStep > 0) {
      setFieldStep((prev) => prev - 1);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
      {/* LEFT: AI MESSAGE (Slightly Higher) */}
      <div className="flex justify-start lg:-mt-10">
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: "easeOut" }}
        >
          <AIMessage
            step={fieldStep + 1}
            name={name}
            isAnimating={false}
            customMessage={currentField.message}
          />
        </motion.div>
      </div>

      {/* RIGHT: USER INPUT (Slightly Lower – Reply Style) */}
      <motion.div
        className="relative max-w-xl w-full lg:mt-10"
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: "easeOut", delay: 0.05 }}
      >
        {/* Ambient Glow */}
        <div
          className="absolute inset-0 -z-10 rounded-[2.8rem] 
          bg-linear-to-br from-indigo-500/10 via-transparent to-rose-500/10 
          blur-3xl"
        />

        {/* Reply Surface */}
        <div
          className="relative bg-white backdrop-blur-2xl 
          border border-slate-200/60 
          rounded-[2.5rem] p-8 md:p-10 
          shadow-[0_30px_80px_rgba(0,0,0,0.12)]"
        >
          {/* Prompt */}
          <h1 className="text-sm font-medium text-slate-500 mb-6">
            {currentField.label}
          </h1>

          {/* Input */}
          <div className="relative group">
            {currentField.type === "select" ? (
              <select
                autoFocus
                value={formData[currentField.key] || ""}
                onChange={handleChange}
                className="w-full appearance-none bg-transparent
                text-xl md:text-xl font-semibold text-slate-900
                border-b border-slate-300/70 pb-3
                focus:outline-none focus:border-indigo-500 transition"
              >
                <option value="">Choose your answer</option>
                {currentField.options.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            ) : (
              <input
                autoFocus
                type={currentField.type}
                placeholder="Type your response…"
                value={formData[currentField.key] || ""}
                onChange={handleChange}
                onKeyDown={(e) => e.key === "Enter" && handleNext()}
                className="w-full bg-transparent
                text-xl md:text-2xl font-semibold text-slate-900
                placeholder:text-slate-400
                border-b border-slate-300/70 pb-3
                focus:outline-none focus:border-indigo-500 transition"
              />
            )}

            {/* Animated Underline */}
            <span
              className="absolute left-0 -bottom-px h-0.5 w-0
              bg-linear-to-r from-indigo-500 to-rose-500
              group-focus-within:w-full transition-all duration-500"
            />
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between mt-8">
            <button
              onClick={goToLastField}
              disabled={!isNameFilled}
              className={`text-sm transition
    ${
      isNameFilled
        ? " bg-linear-to-r from-indigo-500 to-rose-500  px-6 py-2.5 text-white rounded-full"
        : "text-slate-300 cursor-not-allowed"
    }`}
            >
              Skip to last
            </button>

            {/* Actions */}
            <div className="flex items-center gap-4">
              {fieldStep > 0 && (
                <button
                  onClick={handlePrevious}
                  className="text-sm font-medium px-6 py-2.5 bg-black text-slate-50 transition rounded-full"
                >
                  Back
                </button>
              )}

              <button
                onClick={handleNext}
                className="px-6 py-2.5 rounded-full
                bg-color text-sm font-semibold
                shadow-lg shadow-indigo-500/30
                hover:scale-[1.05] active:scale-[0.97]
                transition-all"
              >
                {fieldStep === fields.length - 1 ? "Send" : "Reply"}
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default BasicInfo;
