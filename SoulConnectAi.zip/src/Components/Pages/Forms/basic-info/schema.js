export const basicInfoSchema = {
  name: { required: true },
  dob: { required: true },
};
