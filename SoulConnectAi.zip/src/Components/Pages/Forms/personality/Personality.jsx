
import { useFormStore } from "../../../../store/formStore";

const Personality = ({ onNext }) => {
  const setAnswer = useFormStore(s => s.setAnswer);

  return (
    <div className="space-y-6">
      <textarea
        placeholder="Describe yourself"
        onChange={e =>
          setAnswer("personality", { description: e.target.value })
        }
      />
      <button onClick={onNext}>Next</button>
    </div>
  );
};

export default Personality;
