import { useFormStore } from "../../../../store/formStore";

const Lifestyle = ({ onNext }) => {
  const setAnswer = useFormStore(s => s.setAnswer);

  return (
    <div className="space-y-6">
      <label>
        <input
          type="checkbox"
          onChange={e =>
            setAnswer("lifestyle", { smoking: e.target.checked })
          }
        />
        Smoking
      </label>

      <button onClick={onNext}>Next</button>
    </div>
  );
};

export default Lifestyle;
