import { useFormStore } from "../../../../store/formStore";

 

const AICompatibility = ({ onNext }) => {
  const answers = useFormStore(s => s.answers);

  return (
    <div>
      <p>Analyzing compatibility...</p>
      <pre>{JSON.stringify(answers, null, 2)}</pre>
      <button onClick={onNext}>Proceed</button>
    </div>
  );
};

export default AICompatibility;
