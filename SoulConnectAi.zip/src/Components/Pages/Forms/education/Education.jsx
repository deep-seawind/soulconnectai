import React, { useState } from "react";
import AIMessage from "../../Home/AIMessage";
import { motion } from "framer-motion";

const Education = ({ onNext }) => {
  const fields = [
    {
      key: "highestQualification",
      label: "Highest Qualification",
      type: "select",
      options: [
        "High School",
        "Diploma",
        "Bachelor's Degree",
        "Master's Degree",
        "Doctorate (PhD)",
        "Other",
      ],
      message:
        "Education shapes perspective. What is your highest qualification?",
    },
    {
      key: "fieldOfStudy",
      label: "Field of Study",
      type: "text",
      placeholder: "e.g. Engineering, Commerce, Arts",
      message:
        "Your area of learning matters. What field did you study?",
    },
    {
      key: "currentOccupation",
      label: "Current Occupation",
      type: "text",
      placeholder: "Your current role",
      message:
        "What do you currently do professionally?",
    },
    {
      key: "annualIncomeRange",
      label: "Annual Income Range",
      type: "select",
      options: [
        "Below ₹3 LPA",
        "₹3–5 LPA",
        "₹5–10 LPA",
        "₹10–20 LPA",
        "Above ₹20 LPA",
        "Prefer not to say",
      ],
      message:
        "Financial stability is important. Which income range best fits you?",
    },
    {
      key: "workEnvironment",
      label: "Work Environment",
      type: "select",
      options: ["Remote", "Office", "Hybrid"],
      message:
        "How do you usually work day to day?",
    },
    {
      key: "continueWorkingAfterMarriage",
      label: "Plan to continue working after marriage?",
      type: "select",
      options: ["Yes", "No", "Not Sure"],
      message:
        "Looking ahead matters. Do you plan to continue working after marriage?",
    },
    {
      key: "careerAmbitionLevel",
      label: "Career Ambition Level",
      type: "select",
      options: ["🟢 Balanced", "🟡 Moderate", "🔴 Highly Ambitious"],
      message:
        "Everyone has a different drive. How ambitious are you about your career?",
    },
  ];

  const [fieldStep, setFieldStep] = useState(0);
  const [formData, setFormData] = useState({});
  const [submittedSteps, setSubmittedSteps] = useState({});

  const currentField = fields[fieldStep];

  const handleChange = (e) => {
    const value = e.target.value;
    setFormData((prev) => ({
      ...prev,
      [currentField.key]: value,
    }));
  };

  const handleNext = () => {
    const value = formData[currentField.key];
    if (!value || value.toString().trim() === "") return;

    const trimmedValue = value.toString().trim();

    setFormData((prev) => ({
      ...prev,
      [currentField.key]: trimmedValue,
    }));

    setSubmittedSteps((prev) => ({
      ...prev,
      [currentField.key]: true,
    }));

    if (fieldStep === fields.length - 1) {
      onNext();
    } else {
      setFieldStep((prev) => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (fieldStep > 0) {
      setFieldStep((prev) => prev - 1);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
      {/* LEFT: AI MESSAGE */}
      <div className="flex justify-start lg:-mt-10">
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: "easeOut" }}
        >
          <AIMessage
            step={fieldStep + 1}
            isAnimating={false}
            customMessage={currentField.message}
          />
        </motion.div>
      </div>

      {/* RIGHT: USER INPUT */}
      <motion.div
        className="relative max-w-xl w-full lg:mt-10"
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: "easeOut", delay: 0.05 }}
      >
        {/* Ambient Glow */}
        <div
          className="absolute inset-0 -z-10 rounded-[2.8rem] 
          bg-linear-to-br from-indigo-500/10 via-transparent to-rose-500/10 
          blur-3xl"
        />

        {/* Reply Surface */}
        <div
          className="relative bg-white backdrop-blur-2xl 
          border border-slate-200/60 
          rounded-[2.5rem] p-8 md:p-10 
          shadow-[0_30px_80px_rgba(0,0,0,0.12)]"
        >
          <h1 className="text-sm font-medium text-slate-500 mb-6">
            {currentField.label}
          </h1>

          <div className="relative group">
            {currentField.type === "select" ? (
              <select
                autoFocus
                value={formData[currentField.key] || ""}
                onChange={handleChange}
                className="w-full appearance-none bg-transparent
                text-xl font-semibold text-slate-900
                border-b border-slate-300/70 pb-3
                focus:outline-none focus:border-indigo-500 transition"
              >
                <option value="">Choose your answer</option>
                {currentField.options.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            ) : (
              <input
                autoFocus
                type={currentField.type}
                placeholder="Type your response…"
                value={formData[currentField.key] || ""}
                onChange={handleChange}
                onKeyDown={(e) => e.key === "Enter" && handleNext()}
                className="w-full bg-transparent
                text-xl md:text-2xl font-semibold text-slate-900
                placeholder:text-slate-400
                border-b border-slate-300/70 pb-3
                focus:outline-none focus:border-indigo-500 transition"
              />
            )}

            <span
              className="absolute left-0 -bottom-px h-0.5 w-0
              bg-linear-to-r from-indigo-500 to-rose-500
              group-focus-within:w-full transition-all duration-500"
            />
          </div>

          <div className="flex items-center justify-between mt-8">
            <span className="text-xs text-slate-400">
              Press{" "}
              <kbd className="px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                Enter
              </kbd>{" "}
              to continue
            </span>

            <div className="flex items-center gap-4">
              {fieldStep > 0 && (
                <button
                  onClick={handlePrevious}
                  className="text-sm font-medium text-slate-400 hover:text-slate-700 transition"
                >
                  Back
                </button>
              )}

              <button
                onClick={handleNext}
                className="px-6 py-2.5 rounded-full
                bg-color text-sm font-semibold
                shadow-lg shadow-indigo-500/30
                hover:scale-[1.05] active:scale-[0.97]
                transition-all"
              >
                {fieldStep === fields.length - 1 ? "Send" : "Reply"}
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Education;
