import { useFormStore } from "../../../../store/formStore";

 

const Future = ({ onNext }) => {
  const setAnswer = useFormStore(s => s.setAnswer);

  return (
    <div>
      <textarea
        placeholder="Life Goals"
        onChange={e =>
          setAnswer("future", { goals: e.target.value })
        }
      />
      <button onClick={onNext}>Next</button>
    </div>
  );
};

export default Future;
