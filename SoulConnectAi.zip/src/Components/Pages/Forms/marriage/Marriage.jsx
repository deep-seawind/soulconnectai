import { useFormStore } from "../../../../store/formStore";

const Marriage = ({ onNext }) => {
  const setAnswer = useFormStore(s => s.setAnswer);

  return (
    <div>
      <select onChange={e =>
        setAnswer("marriage", { timeline: e.target.value })
      }>
        <option>1 Year</option>
        <option>2 Years</option>
      </select>
      <button onClick={onNext}>Next</button>
    </div>
  );
};

export default Marriage;
