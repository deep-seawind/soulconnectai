import { useFormStore } from "../../../../store/formStore";

 

const Communication = ({ onNext }) => {
  const setAnswer = useFormStore(s => s.setAnswer);

  return (
    <div>
      <select onChange={e =>
        setAnswer("communication", { style: e.target.value })
      }>
        <option>Open</option>
        <option>Reserved</option>
      </select>
      <button onClick={onNext}>Next</button>
    </div>
  );
};

export default Communication;
