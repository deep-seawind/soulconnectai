import React from "react";
import Mainrouter from "../Router/Mainrouter";

const Layout = () => {
  return (
    <>
      <Mainrouter />
    </>
  );
};

export default Layout;
